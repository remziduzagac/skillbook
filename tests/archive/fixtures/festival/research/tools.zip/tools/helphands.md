# HelpHands

Sheet dated January 2026.

- Cost: free for community groups.
- Accessibility: large-text mode; screen reader support in beta.
- Use: a web page or app; printed rotas can be posted to volunteers without email.
