# RotaEasy

Sheet dated March 2026.

- Cost: free for up to 20 volunteers, then $4 a month.
- Accessibility: works with screen readers; text size can be raised.
- Data: stored in the EU; not shared with advertisers.
- Use: a web page; no app needed; volunteers sign up by text message too.
