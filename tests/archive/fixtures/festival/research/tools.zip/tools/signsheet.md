# SignSheet

Sheet dated November 2025.

- Cost: $6 a month.
- Accessibility: no screen reader support listed.
- Data: stored in the US; volunteer emails used for the company's newsletter unless they opt out.
- Use: needs the SignSheet app on a smartphone.
