# Minestrone

Serves: 6

- 1 onion
- 2 carrots
- 2 celery sticks
- 400 g tomatoes
- 1 courgette
- 100 g pasta
- 400 g white beans
- 1500 ml stock
- 30 g parmesan
