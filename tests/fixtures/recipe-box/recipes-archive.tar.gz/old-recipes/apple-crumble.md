# Apple crumble

Serves: 6

- 6 apples
- 150 g flour
- 100 g butter
- 80 g sugar
- 1 tsp cinnamon
