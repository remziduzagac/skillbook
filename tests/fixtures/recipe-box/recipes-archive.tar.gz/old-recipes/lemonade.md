# Lemonade

Serves: 8

- 6 lemons
- 200 g sugar
- 1500 ml water
