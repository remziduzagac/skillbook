# Porridge

Serves: 2

- 100 g oats
- 500 ml milk
- 1 pinch salt
