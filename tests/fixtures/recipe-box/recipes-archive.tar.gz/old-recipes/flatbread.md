# Flatbread

Serves: 4

- 250 g flour
- 150 ml water
- 1 tsp salt
